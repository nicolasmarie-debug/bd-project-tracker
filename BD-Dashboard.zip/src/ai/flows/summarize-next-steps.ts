'use server';
/**
 * @fileOverview Summarizes project notes and suggests next steps using generative AI.
 *
 * - summarizeNextSteps - A function that summarizes project notes and suggests next steps.
 * - SummarizeNextStepsInput - The input type for the summarizeNextSteps function.
 * - SummarizeNextStepsOutput - The return type for the summarizeNextSteps function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeNextStepsInputSchema = z.object({
  notes: z.string().describe('The notes/next steps for a project.'),
});
export type SummarizeNextStepsInput = z.infer<typeof SummarizeNextStepsInputSchema>;

const SummarizeNextStepsOutputSchema = z.object({
  summary: z.string().describe('A concise summary of the notes and suggested next steps.'),
});
export type SummarizeNextStepsOutput = z.infer<typeof SummarizeNextStepsOutputSchema>;

export async function summarizeNextSteps(input: SummarizeNextStepsInput): Promise<SummarizeNextStepsOutput> {
  return summarizeNextStepsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeNextStepsPrompt',
  input: {schema: SummarizeNextStepsInputSchema},
  output: {schema: SummarizeNextStepsOutputSchema},
  prompt: `You are an AI assistant helping to manage business development projects.
  Given the following notes/next steps for a project, provide a concise summary and suggest actionable next steps.

  Notes/Next Steps: {{{notes}}}

  Summary and Next Steps:`,
});

const summarizeNextStepsFlow = ai.defineFlow(
  {
    name: 'summarizeNextStepsFlow',
    inputSchema: SummarizeNextStepsInputSchema,
    outputSchema: SummarizeNextStepsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
