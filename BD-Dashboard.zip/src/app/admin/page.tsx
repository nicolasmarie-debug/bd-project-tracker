"use client";

import React from 'react';
import { useApp } from '../lib/store';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Users, Tag, Columns, UserPlus, Trash2, Save, Plus, AppWindow } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Stage, Category, TeamMember } from '../lib/types';

export default function AdminPage() {
  const { config, setConfig } = useApp();
  const { toast } = useToast();

  const handleUpdateAppName = (name: string) => {
    setConfig(prev => ({ ...prev, appName: name }));
  };

  const handleUpdateUser = (id: string, updates: Partial<TeamMember>) => {
    setConfig(prev => ({
      ...prev,
      users: prev.users.map(u => u.id === id ? { ...u, ...updates } : u)
    }));
  };

  const handleAddUser = () => {
    const newUser: TeamMember = {
      id: `u-${Date.now()}`,
      name: 'New Member',
      email: '',
      role: 'member',
      color: '#' + Math.floor(Math.random()*16777215).toString(16)
    };
    setConfig(prev => ({ ...prev, users: [...prev.users, newUser] }));
  };

  const handleRemoveUser = (id: string) => {
    setConfig(prev => ({ ...prev, users: prev.users.filter(u => u.id !== id) }));
  };

  const handleUpdateStage = (id: string, updates: Partial<Stage>) => {
    setConfig(prev => ({
      ...prev,
      stages: prev.stages.map(s => s.id === id ? { ...s, ...updates } : s)
    }));
  };

  const handleAddStage = () => {
    const newStage: Stage = {
      id: `s-${Date.now()}`,
      name: 'New Stage',
      color: '#' + Math.floor(Math.random()*16777215).toString(16)
    };
    setConfig(prev => ({ ...prev, stages: [...prev.stages, newStage] }));
  };

  const handleRemoveStage = (id: string) => {
    setConfig(prev => ({ ...prev, stages: prev.stages.filter(s => s.id !== id) }));
  };

  const handleUpdateCategory = (id: string, updates: Partial<Category>) => {
    setConfig(prev => ({
      ...prev,
      categories: prev.categories.map(c => c.id === id ? { ...c, ...updates } : c)
    }));
  };

  const handleAddCategory = () => {
    const newCategory: Category = {
      id: `c-${Date.now()}`,
      name: 'New Category',
      color: '#' + Math.floor(Math.random()*16777215).toString(16)
    };
    setConfig(prev => ({ ...prev, categories: [...prev.categories, newCategory] }));
  };

  const handleRemoveCategory = (id: string) => {
    setConfig(prev => ({ ...prev, categories: prev.categories.filter(c => c.id !== id) }));
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-4xl mx-auto pb-12">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight">Admin Configuration</h1>
        <p className="text-muted-foreground">Customize your pipeline stages, categories, and team structure.</p>
      </div>

      <div className="grid gap-8">
        {/* General Settings */}
        <Card className="shadow-sm border-none shadow-md ring-1 ring-border">
          <CardHeader className="bg-slate-50/50 dark:bg-slate-950/20 rounded-t-lg">
            <CardTitle className="text-xl flex items-center gap-2">
              <AppWindow className="w-5 h-5 text-slate-600" />
              General Settings
            </CardTitle>
            <CardDescription>Basic application branding and preferences.</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-2 max-w-md">
              <Label htmlFor="appName">Dashboard Name</Label>
              <Input 
                id="appName" 
                value={config.appName} 
                onChange={e => handleUpdateAppName(e.target.value)}
                placeholder="Enter dashboard name"
              />
              <p className="text-[11px] text-muted-foreground italic">This name appears in the navigation bar.</p>
            </div>
          </CardContent>
        </Card>

        {/* Team Management */}
        <Card className="shadow-sm border-none shadow-md ring-1 ring-border">
          <CardHeader className="bg-primary/5 rounded-t-lg">
            <CardTitle className="text-xl flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Team Members
            </CardTitle>
            <CardDescription>Manage your BD team and their roles.</CardDescription>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            <div className="space-y-4">
              {config.users.map(user => (
                <div key={user.id} className="flex items-center gap-4 p-4 border rounded-lg bg-card shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shrink-0" style={{ backgroundColor: user.color }}>
                    {user.name.charAt(0)}
                  </div>
                  <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <Label className="text-[10px] uppercase font-bold text-muted-foreground">Name</Label>
                      <Input value={user.name} onChange={e => handleUpdateUser(user.id, { name: e.target.value })} />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] uppercase font-bold text-muted-foreground">Email</Label>
                      <Input value={user.email} onChange={e => handleUpdateUser(user.id, { email: e.target.value })} />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] uppercase font-bold text-muted-foreground">Role</Label>
                      <select 
                        className="w-full h-10 px-3 py-2 border rounded-md text-sm bg-background"
                        value={user.role}
                        onChange={e => handleUpdateUser(user.id, { role: e.target.value as 'admin' | 'member' })}
                      >
                        <option value="member">Member</option>
                        <option value="admin">Admin</option>
                      </select>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="text-destructive shrink-0" onClick={() => handleRemoveUser(user.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full border-dashed border-2" onClick={handleAddUser}>
              <UserPlus className="w-4 h-4 mr-2" /> Add Team Member
            </Button>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Pipeline Stages */}
          <Card className="shadow-sm border-none shadow-md ring-1 ring-border">
            <CardHeader className="bg-orange-50/50 dark:bg-orange-950/20 rounded-t-lg">
              <CardTitle className="text-xl flex items-center gap-2">
                <Columns className="w-5 h-5 text-orange-600" />
                Pipeline Stages
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-3">
                {config.stages.map(stage => (
                  <div key={stage.id} className="flex items-center gap-3">
                    <div className="w-4 h-10 rounded shrink-0" style={{ backgroundColor: stage.color }} />
                    <Input 
                      value={stage.name} 
                      onChange={e => handleUpdateStage(stage.id, { name: e.target.value })}
                      className="flex-1"
                    />
                    <Input 
                      type="color" 
                      value={stage.color} 
                      onChange={e => handleUpdateStage(stage.id, { color: e.target.value })}
                      className="w-12 p-0 h-10 shrink-0"
                    />
                    <Button variant="ghost" size="icon" className="text-destructive shrink-0" onClick={() => handleRemoveStage(stage.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
              <Button variant="outline" size="sm" className="w-full border-dashed" onClick={handleAddStage}>
                <Plus className="w-4 h-4 mr-2" /> Add Stage
              </Button>
            </CardContent>
          </Card>

          {/* Category Tags */}
          <Card className="shadow-sm border-none shadow-md ring-1 ring-border">
            <CardHeader className="bg-blue-50/50 dark:bg-blue-950/20 rounded-t-lg">
              <CardTitle className="text-xl flex items-center gap-2">
                <Tag className="w-5 h-5 text-blue-600" />
                Category Tags
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-3">
                {config.categories.map(cat => (
                  <div key={cat.id} className="flex items-center gap-3">
                    <div className="w-4 h-10 rounded shrink-0" style={{ backgroundColor: cat.color }} />
                    <Input 
                      value={cat.name} 
                      onChange={e => handleUpdateCategory(cat.id, { name: e.target.value })}
                      className="flex-1"
                    />
                    <Input 
                      type="color" 
                      value={cat.color} 
                      onChange={e => handleUpdateCategory(cat.id, { color: e.target.value })}
                      className="w-12 p-0 h-10 shrink-0"
                    />
                    <Button variant="ghost" size="icon" className="text-destructive shrink-0" onClick={() => handleRemoveCategory(cat.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
              <Button variant="outline" size="sm" className="w-full border-dashed" onClick={handleAddCategory}>
                <Plus className="w-4 h-4 mr-2" /> Add Category
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end p-4">
          <Button 
            className="bg-primary hover:bg-primary/90 text-white" 
            onClick={() => toast({ title: 'Config Saved', description: 'All changes have been applied successfully.' })}
          >
            <Save className="w-4 h-4 mr-2" />
            Save All Configurations
          </Button>
        </div>
      </div>
    </div>
  );
}
