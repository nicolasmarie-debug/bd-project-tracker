"use client";

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Project, AppConfig, Stage, Category, TeamMember } from './types';

interface AppContextType {
  projects: Project[];
  config: AppConfig;
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  setConfig: React.Dispatch<React.SetStateAction<AppConfig>>;
  addProject: (p: Omit<Project, 'id' | 'createdAt' | 'archived'>) => void;
  updateProject: (id: string, p: Partial<Project>) => void;
  deleteProject: (id: string) => void;
}

const defaultConfig: AppConfig = {
  appName: 'Pipeline Pro',
  stages: [
    { id: 'exploration', name: 'Exploration', color: '#e65100' },
    { id: 'validation', name: 'Validation', color: '#1565c0' },
    { id: 'execution', name: 'Execution', color: '#2e7d32' },
    { id: 'onhold', name: 'On Hold/Dropped', color: '#616161' }
  ],
  categories: [
    { id: 'bd', name: 'BD', color: '#c62828' },
    { id: 'strategy', name: 'Strategy', color: '#1565c0' },
    { id: 'crosssell', name: 'Cross-Sell', color: '#7b1fa2' },
    { id: 'pm', name: 'Product', color: '#00695c' },
    { id: 'bpi', name: 'Process', color: '#f9a825' },
    { id: 'websites', name: 'Marketing', color: '#ad1457' }
  ],
  users: [
    { id: 'u1', name: 'Sarah Kim', email: 'sarah.kim@company.com', role: 'admin', color: '#c62828' },
    { id: 'u2', name: 'John Chen', email: 'john.chen@company.com', role: 'member', color: '#1565c0' },
    { id: 'u3', name: 'Emily Johnson', email: 'emily.j@company.com', role: 'member', color: '#2e7d32' }
  ]
};

const defaultProjects: Project[] = [
  {
    id: 'p1',
    title: 'AI Strategic Agent Rollout',
    stage: 'exploration',
    categories: ['bd', 'strategy'],
    impact: '$200K ARR',
    leadOwner: 'u1',
    supportOwner: 'u2',
    notes: 'APIs by Oct 21 - Strategic LI engagement',
    startDate: '2026-01-15',
    targetDate: '2026-03-31',
    decisionRequired: false,
    archived: false,
    createdAt: '2026-01-15'
  },
  {
    id: 'p2',
    title: 'APAC Business Process Refactor',
    stage: 'validation',
    categories: ['bpi', 'strategy'],
    impact: '$800K Savings',
    leadOwner: 'u3',
    supportOwner: 'u1',
    notes: 'R-align capacity + losses - Decision needed',
    startDate: '2025-10-01',
    targetDate: '2026-02-28',
    decisionRequired: true,
    archived: false,
    createdAt: '2025-10-01'
  }
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [config, setConfig] = useState<AppConfig>(defaultConfig);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('pipeline_pro_data');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setProjects(parsed.projects || defaultProjects);
        // Ensure appName exists in case it was saved before this update
        const savedConfig = parsed.config || defaultConfig;
        if (!savedConfig.appName) savedConfig.appName = defaultConfig.appName;
        setConfig(savedConfig);
      } catch (e) {
        setProjects(defaultProjects);
        setConfig(defaultConfig);
      }
    } else {
      setProjects(defaultProjects);
      setConfig(defaultConfig);
    }
    setInitialized(true);
  }, []);

  useEffect(() => {
    if (initialized) {
      localStorage.setItem('pipeline_pro_data', JSON.stringify({ projects, config }));
    }
  }, [projects, config, initialized]);

  const addProject = (p: Omit<Project, 'id' | 'createdAt' | 'archived'>) => {
    const newProject: Project = {
      ...p,
      id: `p-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
      archived: false
    };
    setProjects(prev => [...prev, newProject]);
  };

  const updateProject = (id: string, p: Partial<Project>) => {
    setProjects(prev => prev.map(proj => proj.id === id ? { ...proj, ...p } : proj));
  };

  const deleteProject = (id: string) => {
    setProjects(prev => prev.filter(proj => proj.id !== id));
  };

  return (
    <AppContext.Provider value={{ projects, config, setProjects, setConfig, addProject, updateProject, deleteProject }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
