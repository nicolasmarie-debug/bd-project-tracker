export interface Stage {
  id: string;
  name: string;
  color: string;
}

export interface Category {
  id: string;
  name: string;
  color: string;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'member';
  color: string;
}

export interface Project {
  id: string;
  title: string;
  stage: string;
  categories: string[];
  impact: string;
  leadOwner: string;
  supportOwner: string;
  notes: string;
  startDate?: string;
  targetDate?: string;
  decisionRequired: boolean;
  archived: boolean;
  createdAt: string;
}

export interface AppConfig {
  appName: string;
  stages: Stage[];
  categories: Category[];
  users: TeamMember[];
}
