"use client";

import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from './lib/store';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Plus, Search, AlertCircle, BarChart3, Rocket } from 'lucide-react';
import KanbanColumn from '@/components/KanbanColumn';
import ProjectDialog from '@/components/ProjectDialog';

export default function Dashboard() {
  const { projects, config } = useApp();
  const [search, setSearch] = useState('');
  const [filterOwner, setFilterOwner] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [isNewProjectOpen, setIsNewProjectOpen] = useState(false);
  const [currentDate, setCurrentDate] = useState<string | null>(null);

  useEffect(() => {
    // Set the date only after hydration to avoid mismatch
    setCurrentDate(new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }));
  }, []);

  const stats = useMemo(() => {
    const active = projects.filter(p => !p.archived && p.stage !== 'onhold');
    const decision = projects.filter(p => p.decisionRequired && !p.archived);
    return {
      total: active.length,
      decision: decision.length,
      newThisMonth: projects.filter(p => {
        const d = new Date(p.createdAt);
        const now = new Date();
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      }).length
    };
  }, [projects]);

  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      if (p.archived) return false;
      const matchesSearch = p.title.toLowerCase().includes(search.toLowerCase()) || 
                            p.notes.toLowerCase().includes(search.toLowerCase());
      const matchesOwner = filterOwner === 'all' || p.leadOwner === filterOwner || p.supportOwner === filterOwner;
      const matchesCategory = filterCategory === 'all' || p.categories.includes(filterCategory);
      return matchesSearch && matchesOwner && matchesCategory;
    });
  }, [projects, search, filterOwner, filterCategory]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight">{config.appName} Pipeline</h1>
        <p className="text-muted-foreground min-h-[1.5rem]">{currentDate || '...'}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Active</CardTitle>
            <BarChart3 className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card className="shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">New This Month</CardTitle>
            <Rocket className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stats.newThisMonth}</div>
          </CardContent>
        </Card>
        <Card className="shadow-sm border-orange-200 bg-orange-50/30">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-orange-700">Decision Required</CardTitle>
            <AlertCircle className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-700">{stats.decision}</div>
          </CardContent>
        </Card>
      </div>

      <div className="bg-card p-4 rounded-lg shadow-sm border flex flex-wrap items-center gap-4">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search projects..." 
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {config.categories.map(cat => (
              <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filterOwner} onValueChange={setFilterOwner}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Owner" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Owners</SelectItem>
            {config.users.map(user => (
              <SelectItem key={user.id} value={user.id}>{user.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button onClick={() => setIsNewProjectOpen(true)} className="bg-primary hover:bg-primary/90 text-white font-semibold">
          <Plus className="w-4 h-4 mr-2" />
          New Project
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {config.stages.map(stage => (
          <KanbanColumn 
            key={stage.id} 
            stage={stage} 
            projects={filteredProjects.filter(p => p.stage === stage.id)}
          />
        ))}
      </div>

      <ProjectDialog 
        open={isNewProjectOpen} 
        onOpenChange={setIsNewProjectOpen} 
        mode="create" 
      />
    </div>
  );
}
