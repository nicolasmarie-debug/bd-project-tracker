"use client";

import React, { useMemo } from 'react';
import { useApp } from '../lib/store';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FileText, Download, Printer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function ReportPage() {
  const { projects, config } = useApp();
  const { toast } = useToast();

  const activeProjects = useMemo(() => projects.filter(p => !p.archived), [projects]);

  const summary = useMemo(() => {
    return config.stages.map(stage => {
      const count = activeProjects.filter(p => p.stage === stage.id).length;
      return { ...stage, count };
    });
  }, [activeProjects, config.stages]);

  const handleExport = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + ["Title,Stage,Categories,Impact,Lead,Support,Notes,TargetDate"].join(",") + "\n"
      + activeProjects.map(p => {
        const lead = config.users.find(u => u.id === p.leadOwner)?.name || '';
        const support = config.users.find(u => u.id === p.supportOwner)?.name || '';
        const cats = p.categories.map(c => config.categories.find(cat => cat.id === c)?.name).join('; ');
        return `"${p.title}","${p.stage}","${cats}","${p.impact}","${lead}","${support}","${p.notes}","${p.targetDate || ''}"`;
      }).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `pipeline_report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({ title: 'Export Complete', description: 'Your CSV report has been downloaded.' });
  };

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Pipeline Status Report</h1>
          <p className="text-muted-foreground">Comprehensive overview of all business development activities</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => window.print()} className="gap-2">
            <Printer className="w-4 h-4" /> Print
          </Button>
          <Button size="sm" onClick={handleExport} className="bg-primary hover:bg-primary/90 gap-2">
            <Download className="w-4 h-4" /> Export CSV
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {summary.map(s => (
          <Card key={s.id} className="text-center">
            <CardHeader className="p-4 pb-0">
              <CardTitle className="text-xs uppercase text-muted-foreground font-semibold">{s.name}</CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-2">
              <div className="text-4xl font-bold" style={{ color: s.color }}>{s.count}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            Project Details
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Project Title</TableHead>
                <TableHead>Stage</TableHead>
                <TableHead>Impact</TableHead>
                <TableHead>Owners</TableHead>
                <TableHead className="hidden md:table-cell">Next Steps</TableHead>
                <TableHead className="text-right">Target Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {activeProjects.map(project => {
                const stage = config.stages.find(s => s.id === project.stage);
                const lead = config.users.find(u => u.id === project.leadOwner);
                const support = config.users.find(u => u.id === project.supportOwner);
                
                return (
                  <TableRow key={project.id}>
                    <TableCell className="font-semibold">{project.title}</TableCell>
                    <TableCell>
                      <Badge variant="outline" style={{ color: stage?.color, borderColor: stage?.color + '40', backgroundColor: stage?.color + '10' }}>
                        {stage?.name}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-primary font-medium">{project.impact || 'TBC'}</TableCell>
                    <TableCell>
                      <div className="text-xs">
                        <div className="font-medium">{lead?.name}</div>
                        <div className="text-muted-foreground">{support?.name}</div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell max-w-xs truncate text-xs text-muted-foreground">
                      {project.notes}
                    </TableCell>
                    <TableCell className="text-right text-xs">
                      {project.targetDate ? new Date(project.targetDate).toLocaleDateString() : '-'}
                    </TableCell>
                  </TableRow>
                );
              })}
              {activeProjects.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                    No active projects found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}