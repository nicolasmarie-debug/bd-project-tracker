"use client";

import { Stage, Project } from '@/app/lib/types';
import ProjectCard from './ProjectCard';
import { Badge } from '@/components/ui/badge';

interface KanbanColumnProps {
  stage: Stage;
  projects: Project[];
}

export default function KanbanColumn({ stage, projects }: KanbanColumnProps) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between pb-2 border-b-2" style={{ borderBottomColor: stage.color }}>
        <h3 className="font-bold text-sm uppercase tracking-wider flex items-center gap-2" style={{ color: stage.color }}>
          {stage.name}
        </h3>
        <Badge variant="secondary" className="bg-muted text-muted-foreground">
          {projects.length}
        </Badge>
      </div>
      
      <div className="flex flex-col gap-4 kanban-column overflow-y-auto pr-1">
        {projects.length > 0 ? (
          projects.map(project => (
            <ProjectCard key={project.id} project={project} />
          ))
        ) : (
          <div className="h-32 rounded-lg border-2 border-dashed flex items-center justify-center text-muted-foreground text-xs text-center p-4">
            No projects in {stage.name}
          </div>
        )}
      </div>
    </div>
  );
}