"use client";

import React, { useState } from 'react';
import { Project } from '@/app/lib/types';
import { useApp } from '@/app/lib/store';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MoreVertical, Calendar, DollarSign, AlertTriangle } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import ProjectDialog from './ProjectDialog';
import { format } from 'date-fns';

interface ProjectCardProps {
  project: Project;
}

export default function ProjectCard({ project }: ProjectCardProps) {
  const { config, updateProject, deleteProject } = useApp();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const lead = config.users.find(u => u.id === project.leadOwner);
  const support = config.users.find(u => u.id === project.supportOwner);
  const projectCategories = project.categories.map(cid => config.categories.find(c => c.id === cid)).filter(Boolean);

  const handleArchive = () => {
    updateProject(project.id, { archived: !project.archived });
  };

  const handleDuplicate = () => {
    // Basic duplication
    const { id, createdAt, ...rest } = project;
    updateProject(project.id, { ...rest, title: `${project.title} (Copy)` });
  };

  const getInitials = (name: string) => name.split(' ').map(n => n[0]).join('').toUpperCase();

  return (
    <>
      <Card 
        className="project-card shadow-sm hover:shadow-md cursor-pointer relative group border-l-4"
        style={{ borderLeftColor: lead?.color || '#ccc' }}
        onClick={() => setIsEditDialogOpen(true)}
      >
        <CardHeader className="p-4 pb-2 flex flex-row items-start justify-between">
          <CardTitle className="text-sm font-semibold line-clamp-2 pr-6">
            {project.title}
          </CardTitle>
          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <button className="h-8 w-8 rounded-full hover:bg-muted flex items-center justify-center text-muted-foreground">
                <MoreVertical className="w-4 h-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setIsEditDialogOpen(true)}>Edit</DropdownMenuItem>
              <DropdownMenuItem onClick={handleDuplicate}>Duplicate</DropdownMenuItem>
              <DropdownMenuItem onClick={handleArchive}>{project.archived ? 'Unarchive' : 'Archive'}</DropdownMenuItem>
              <DropdownMenuItem className="text-destructive" onClick={() => deleteProject(project.id)}>Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </CardHeader>
        
        <CardContent className="p-4 pt-0 space-y-3">
          <div className="flex flex-wrap gap-1">
            {projectCategories.map(cat => (
              <Badge key={cat?.id} variant="outline" className="text-[10px] h-5 px-1.5" style={{ color: cat?.color, borderColor: cat?.color + '40' }}>
                {cat?.name}
              </Badge>
            ))}
          </div>

          {project.impact && (
            <div className="flex items-center gap-1.5 text-xs font-medium text-primary">
              <DollarSign className="w-3 h-3" />
              Impact: {project.impact}
            </div>
          )}

          {project.notes && (
            <div className="bg-muted/50 p-2 rounded text-[11px] text-muted-foreground line-clamp-2 border italic leading-snug">
              {project.notes}
            </div>
          )}
        </CardContent>

        <CardFooter className="p-4 pt-0 flex items-center justify-between">
          <div className="flex -space-x-2">
            {lead && (
              <Avatar className="h-6 w-6 border-2 border-white" title={`${lead.name} (Lead)`}>
                <AvatarFallback style={{ backgroundColor: lead.color }} className="text-[10px] text-white">
                  {getInitials(lead.name)}
                </AvatarFallback>
              </Avatar>
            )}
            {support && (
              <Avatar className="h-6 w-6 border-2 border-white" title={`${support.name} (Support)`}>
                <AvatarFallback style={{ backgroundColor: support.color }} className="text-[10px] text-white">
                  {getInitials(support.name)}
                </AvatarFallback>
              </Avatar>
            )}
          </div>
          
          {project.targetDate && (
            <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
              <Calendar className="w-3 h-3" />
              {format(new Date(project.targetDate), 'MMM d, yy')}
            </div>
          )}
        </CardFooter>

        {project.decisionRequired && (
          <div className="absolute top-2 right-2 flex items-center justify-center" title="Decision Required">
            <AlertTriangle className="w-4 h-4 text-orange-500 fill-orange-500" />
          </div>
        )}
      </Card>

      <ProjectDialog 
        open={isEditDialogOpen} 
        onOpenChange={setIsEditDialogOpen} 
        project={project}
        mode="edit"
      />
    </>
  );
}