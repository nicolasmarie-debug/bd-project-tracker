"use client";

import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useApp } from '@/app/lib/store';
import { Project } from '@/app/lib/types';
import { Sparkles, Loader2 } from 'lucide-react';
import { summarizeNextSteps } from '@/ai/flows/summarize-next-steps';
import { useToast } from '@/hooks/use-toast';

interface ProjectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  project?: Project;
  mode: 'create' | 'edit';
}

export default function ProjectDialog({ open, onOpenChange, project, mode }: ProjectDialogProps) {
  const { config, addProject, updateProject } = useApp();
  const { toast } = useToast();
  const [formData, setFormData] = useState<Partial<Project>>({});
  const [isSummarizing, setIsSummarizing] = useState(false);

  useEffect(() => {
    if (project && mode === 'edit') {
      setFormData(project);
    } else {
      setFormData({
        title: '',
        stage: config.stages[0]?.id || 'exploration',
        categories: [],
        impact: '',
        leadOwner: '',
        supportOwner: '',
        notes: '',
        decisionRequired: false,
        startDate: new Date().toISOString().split('T')[0]
      });
    }
  }, [project, mode, open, config.stages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title) return;

    if (mode === 'create') {
      addProject(formData as Omit<Project, 'id' | 'createdAt' | 'archived'>);
      toast({ title: 'Project Created', description: `Successfully added ${formData.title}` });
    } else if (project) {
      updateProject(project.id, formData);
      toast({ title: 'Project Updated', description: `Successfully saved changes to ${formData.title}` });
    }
    onOpenChange(false);
  };

  const toggleCategory = (catId: string) => {
    setFormData(prev => {
      const cats = prev.categories || [];
      if (cats.includes(catId)) {
        return { ...prev, categories: cats.filter(c => c !== catId) };
      }
      return { ...prev, categories: [...cats, catId] };
    });
  };

  const handleAISummarize = async () => {
    if (!formData.notes) {
      toast({ variant: 'destructive', title: 'Error', description: 'Please enter some notes first.' });
      return;
    }

    setIsSummarizing(true);
    try {
      const result = await summarizeNextSteps({ notes: formData.notes });
      setFormData(prev => ({ ...prev, notes: result.summary }));
      toast({ title: 'AI Summary Generated', description: 'Notes have been summarized and optimized.' });
    } catch (error) {
      toast({ variant: 'destructive', title: 'AI Error', description: 'Could not generate summary at this time.' });
    } finally {
      setIsSummarizing(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === 'create' ? 'New Project' : 'Edit Project'}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">Project Title *</Label>
              <Input 
                id="title" 
                value={formData.title} 
                onChange={e => setFormData({ ...formData, title: e.target.value })} 
                required 
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="stage">Stage</Label>
                <Select value={formData.stage} onValueChange={v => setFormData({ ...formData, stage: v })}>
                  <SelectTrigger id="stage">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {config.stages.map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="impact">Impact</Label>
                <Input 
                  id="impact" 
                  placeholder="e.g. $500K" 
                  value={formData.impact} 
                  onChange={e => setFormData({ ...formData, impact: e.target.value })} 
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Categories</Label>
              <div className="flex flex-wrap gap-3 p-3 border rounded-md">
                {config.categories.map(cat => (
                  <label key={cat.id} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted p-1 rounded transition-colors">
                    <Checkbox 
                      checked={formData.categories?.includes(cat.id)} 
                      onCheckedChange={() => toggleCategory(cat.id)} 
                    />
                    {cat.name}
                  </label>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="lead">Lead Owner</Label>
                <Select value={formData.leadOwner} onValueChange={v => setFormData({ ...formData, leadOwner: v })}>
                  <SelectTrigger id="lead">
                    <SelectValue placeholder="Select Lead" />
                  </SelectTrigger>
                  <SelectContent>
                    {config.users.map(u => <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="support">Support Owner</Label>
                <Select value={formData.supportOwner} onValueChange={v => setFormData({ ...formData, supportOwner: v })}>
                  <SelectTrigger id="support">
                    <SelectValue placeholder="Select Support" />
                  </SelectTrigger>
                  <SelectContent>
                    {config.users.map(u => <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="notes">Notes & Next Steps</Label>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  className="h-8 gap-1.5 text-xs text-primary border-primary/20 hover:bg-primary/5"
                  onClick={handleAISummarize}
                  disabled={isSummarizing || !formData.notes}
                >
                  {isSummarizing ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5" />
                  )}
                  AI Optimize
                </Button>
              </div>
              <Textarea 
                id="notes" 
                className="min-h-[120px]" 
                placeholder="Key updates, next steps, or project hurdles..." 
                value={formData.notes}
                onChange={e => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="start">Start Date</Label>
                <Input 
                  id="start" 
                  type="date" 
                  value={formData.startDate} 
                  onChange={e => setFormData({ ...formData, startDate: e.target.value })} 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="target">Target Date</Label>
                <Input 
                  id="target" 
                  type="date" 
                  value={formData.targetDate} 
                  onChange={e => setFormData({ ...formData, targetDate: e.target.value })} 
                />
              </div>
            </div>

            <div className="flex items-center space-x-2 pt-2">
              <Checkbox 
                id="decision" 
                checked={formData.decisionRequired} 
                onCheckedChange={v => setFormData({ ...formData, decisionRequired: !!v })} 
              />
              <Label htmlFor="decision" className="font-normal text-sm cursor-pointer">
                Management decision required (Flag for attention)
              </Label>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" className="bg-primary hover:bg-primary/90">
              {mode === 'create' ? 'Create Project' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}